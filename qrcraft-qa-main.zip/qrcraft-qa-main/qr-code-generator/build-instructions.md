
# Build Instructions for QR Code Generator WordPress Plugin

To compile the React application for WordPress:

1. Install dependencies:
```
npm install react react-dom qrcode webpack webpack-cli babel-loader @babel/core @babel/preset-env @babel/preset-react css-loader style-loader
```

2. Create a `webpack.config.js` file in the project root:
```javascript
const path = require('path');

module.exports = {
  entry: './src/index.js',
  output: {
    path: path.resolve(__dirname, 'assets/js'),
    filename: 'qr-generator-app.js',
  },
  module: {
    rules: [
      {
        test: /\.(js|jsx)$/,
        exclude: /node_modules/,
        use: {
          loader: 'babel-loader',
          options: {
            presets: ['@babel/preset-env', '@babel/preset-react']
          }
        }
      }
    ]
  },
  externals: {
    'react': 'React',
    'react-dom': 'ReactDOM',
    'qrcode': 'QRCode'
  }
};
```

3. Create a `src/index.js` file:
```javascript
import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';

document.addEventListener('DOMContentLoaded', function() {
  const container = document.getElementById('qr-code-generator');
  if (container) {
    ReactDOM.render(<App />, container);
  }
});
```

4. Run the build process:
```
npx webpack --mode=production
```

5. Copy the QRCode.js library to the assets/js folder.
Download from: https://cdn.jsdelivr.net/npm/qrcode@1.5.3/build/qrcode.min.js

6. Get React and ReactDOM production builds:
- https://unpkg.com/react@18.3.1/umd/react.production.min.js
- https://unpkg.com/react-dom@18.3.1/umd/react-dom.production.min.js

7. Place all compiled assets in their respective folders:
- JavaScript files in `/assets/js/`
- CSS files in `/assets/css/`

8. Zip the entire plugin directory for distribution.
