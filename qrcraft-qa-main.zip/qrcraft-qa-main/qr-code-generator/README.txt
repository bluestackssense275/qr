
=== QR Code Generator ===
Contributors: qrcodegenerator
Tags: qr code, qr generator, shortcode
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 1.0.0
License: GPL v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Create customizable QR codes on your WordPress site with a simple shortcode.

== Description ==

QR Code Generator allows you to create customizable QR codes for various purposes directly on your WordPress website. Simply use the [QR_Code] shortcode to embed the generator on any page or post.

Features:

* Generate QR codes for URLs, text, WiFi, contacts, social media, and more
* Customize colors
* Save QR codes to your media library
* Simple shortcode implementation

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/qr-code-generator` directory, or install the plugin through the WordPress plugins screen.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Use the shortcode [QR_Code] on any page or post to display the QR code generator.

== Usage ==

Basic usage:
[QR_Code]

With parameters:
[QR_Code type="url" default_value="https://example.com"]

Available types:
* url - Website URL
* text - Plain text
* wifi - WiFi network details
* contact - Contact information
* instagram - Instagram profile link
* youtube - YouTube channel
* whatsapp - WhatsApp contact
* email - Email address
* sms - SMS message
* payment - Payment links

== Frequently Asked Questions ==

= How do I embed the QR code generator on my page? =

Simply add the shortcode [QR_Code] to any page or post where you want the generator to appear.

= Can I customize the default QR code type? =

Yes, you can set the default type and value using shortcode attributes:
[QR_Code type="url" default_value="https://example.com"]

== Screenshots ==

1. QR Code Generator in action
2. Admin settings page

== Changelog ==

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.0.0 =
Initial release.
