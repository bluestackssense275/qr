
<?php
/**
 * QR Code Generator Settings Page
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Add admin menu
function qr_generator_add_admin_menu() {
    add_menu_page(
        'QR Code Generator',
        'QR Code Generator',
        'manage_options',
        'qr-code-generator',
        'qr_generator_settings_page',
        'dashicons-admin-generic',
        100
    );
}
add_action('admin_menu', 'qr_generator_add_admin_menu');

// Settings page content
function qr_generator_settings_page() {
    ?>
    <div class="wrap">
        <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
        <p>Use the shortcode <code>[QR_Code]</code> to embed the QR code generator on any page or post.</p>
        <p>You can customize the default type and value using attributes:</p>
        <pre>[QR_Code type="url" default_value="https://example.com"]</pre>
        <p>Available types:</p>
        <ul>
            <li><strong>url</strong> - Website URL</li>
            <li><strong>text</strong> - Plain text</li>
            <li><strong>wifi</strong> - WiFi network details</li>
            <li><strong>contact</strong> - Contact information</li>
            <li><strong>instagram</strong> - Instagram profile link</li>
            <li><strong>youtube</strong> - YouTube channel</li>
            <li><strong>whatsapp</strong> - WhatsApp contact</li>
            <li><strong>email</strong> - Email address</li>
            <li><strong>sms</strong> - SMS message</li>
            <li><strong>payment</strong> - Payment links</li>
        </ul>
    </div>
    <?php
}
