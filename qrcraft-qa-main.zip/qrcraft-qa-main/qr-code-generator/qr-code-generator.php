
<?php
/**
 * Plugin Name: QR Code Generator
 * Description: Generate customizable QR codes with a shortcode.
 * Version: 1.0.0
 * Author: QR Code Generator
 * Text Domain: qr-code-generator
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('QR_GENERATOR_PATH', plugin_dir_path(__FILE__));
define('QR_GENERATOR_URL', plugin_dir_url(__FILE__));
define('QR_GENERATOR_VERSION', '1.0.0');

// Enqueue scripts and styles
function qr_generator_enqueue_scripts() {
    wp_enqueue_style('qr-generator-styles', QR_GENERATOR_URL . 'assets/css/qr-generator.css', array(), QR_GENERATOR_VERSION);
    wp_enqueue_script('qrcode-js', QR_GENERATOR_URL . 'assets/js/qrcode.min.js', array(), QR_GENERATOR_VERSION, true);
    wp_enqueue_script('react', QR_GENERATOR_URL . 'assets/js/react.production.min.js', array(), '18.3.1', true);
    wp_enqueue_script('react-dom', QR_GENERATOR_URL . 'assets/js/react-dom.production.min.js', array('react'), '18.3.1', true);
    wp_enqueue_script('qr-generator-app', QR_GENERATOR_URL . 'assets/js/qr-generator-app.js', array('react', 'react-dom', 'qrcode-js'), QR_GENERATOR_VERSION, true);
    
    // Pass variables to JavaScript
    wp_localize_script('qr-generator-app', 'qrGeneratorData', array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('qr_generator_nonce'),
    ));
}
add_action('wp_enqueue_scripts', 'qr_generator_enqueue_scripts');

// Register shortcode
function qr_code_generator_shortcode($atts) {
    // Enqueue scripts specifically for the shortcode
    qr_generator_enqueue_scripts();
    
    $atts = shortcode_atts(array(
        'type' => 'url',
        'default_value' => '',
    ), $atts, 'qr_code');
    
    // Return the container div where React will mount
    return '<div id="qr-code-generator" 
                data-type="' . esc_attr($atts['type']) . '" 
                data-default="' . esc_attr($atts['default_value']) . '">
                Loading QR Code Generator...
            </div>';
}
add_shortcode('QR_Code', 'qr_code_generator_shortcode');

// Include the admin settings page
require_once QR_GENERATOR_PATH . 'admin/settings.php';

// AJAX handler for saving QR codes to media library
function qr_generator_save_qr_code() {
    // Check nonce for security
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'qr_generator_nonce')) {
        wp_send_json_error('Security check failed');
    }
    
    // Get the image data
    $image_data = isset($_POST['image_data']) ? $_POST['image_data'] : '';
    if (empty($image_data)) {
        wp_send_json_error('No image data received');
    }
    
    // Remove header from base64 encoded image
    $image_data = str_replace('data:image/png;base64,', '', $image_data);
    $image_data = str_replace(' ', '+', $image_data);
    
    // Decode the base64 string
    $decoded_image = base64_decode($image_data);
    
    // Generate a filename
    $filename = 'qr-code-' . time() . '.png';
    
    // Upload to WordPress media library
    $upload = wp_upload_bits($filename, null, $decoded_image);
    
    if ($upload['error']) {
        wp_send_json_error('Failed to save the QR code: ' . $upload['error']);
    }
    
    // Prepare the attachment data
    $attachment = array(
        'post_mime_type' => 'image/png',
        'post_title' => 'QR Code - ' . date('Y-m-d H:i:s'),
        'post_content' => '',
        'post_status' => 'inherit'
    );
    
    // Insert the attachment
    $attach_id = wp_insert_attachment($attachment, $upload['file']);
    
    // Generate metadata for the attachment
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    $attach_data = wp_generate_attachment_metadata($attach_id, $upload['file']);
    wp_update_attachment_metadata($attach_id, $attach_data);
    
    // Send success response with URL
    wp_send_json_success(array(
        'url' => $upload['url'],
        'id' => $attach_id
    ));
}
add_action('wp_ajax_qr_generator_save_qr_code', 'qr_generator_save_qr_code');
add_action('wp_ajax_nopriv_qr_generator_save_qr_code', 'qr_generator_save_qr_code');
