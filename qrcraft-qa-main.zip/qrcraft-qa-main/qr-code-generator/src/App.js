
import React, { useState, useEffect, useRef } from 'react';
import QRCode from 'qrcode';

const App = () => {
  // State for QR code data
  const [qrType, setQrType] = useState('url');
  const [qrData, setQrData] = useState('');
  const [generatedQrData, setGeneratedQrData] = useState('');
  
  // QR Code appearance options
  const [foregroundColor, setForegroundColor] = useState('#000000');
  const [backgroundColor, setBackgroundColor] = useState('#FFFFFF');
  const qrCanvasRef = useRef(null);

  // Get initial values from container data attributes
  useEffect(() => {
    const container = document.getElementById('qr-code-generator');
    if (container) {
      const type = container.getAttribute('data-type') || 'url';
      const defaultValue = container.getAttribute('data-default') || '';
      setQrType(type);
      setQrData(defaultValue);
    }
  }, []);

  // Generate QR code
  const generateQRCode = () => {
    if (!qrData) return;
    
    setGeneratedQrData(qrData);
    
    const canvas = qrCanvasRef.current;
    if (canvas) {
      QRCode.toCanvas(canvas, qrData, {
        width: 250,
        margin: 2,
        color: {
          dark: foregroundColor,
          light: backgroundColor
        }
      }, (error) => {
        if (error) console.error("Error generating QR code:", error);
      });
    }
  };

  // Save QR code to WordPress media library
  const saveToMediaLibrary = () => {
    const canvas = qrCanvasRef.current;
    if (!canvas) return;
    
    const imageData = canvas.toDataURL('image/png');
    
    // Use WordPress AJAX
    const formData = new FormData();
    formData.append('action', 'qr_generator_save_qr_code');
    formData.append('image_data', imageData);
    formData.append('nonce', qrGeneratorData.nonce);
    
    fetch(qrGeneratorData.ajaxUrl, {
      method: 'POST',
      body: formData,
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        alert('QR code saved to media library!');
        // Optionally: Show the URL or provide a download link
      } else {
        alert('Failed to save QR code: ' + data.data);
      }
    })
    .catch(err => {
      console.error('Error saving QR code:', err);
      alert('Error saving QR code. Please try again.');
    });
  };

  // Simplified UI compared to the original React app
  return (
    <div className="qr-generator-container">
      <div className="qr-generator-options">
        <div className="qr-generator-select">
          <label htmlFor="qr-type">QR Code Type:</label>
          <select 
            id="qr-type"
            value={qrType} 
            onChange={(e) => setQrType(e.target.value)}
          >
            <option value="url">Website URL</option>
            <option value="text">Plain Text</option>
            <option value="wifi">WiFi Network</option>
            <option value="contact">Contact</option>
            <option value="instagram">Instagram</option>
            <option value="youtube">YouTube</option>
            <option value="whatsapp">WhatsApp</option>
            <option value="email">Email</option>
            <option value="sms">SMS</option>
            <option value="payment">Payment</option>
          </select>
        </div>
        
        <div className="qr-generator-input">
          <label htmlFor="qr-data">Enter {qrType === 'url' ? 'URL' : qrType === 'text' ? 'Text' : qrType}:</label>
          <input
            id="qr-data"
            type="text"
            value={qrData}
            onChange={(e) => setQrData(e.target.value)}
            placeholder={`Enter ${qrType} here...`}
          />
        </div>
        
        <div className="qr-generator-colors">
          <div>
            <label htmlFor="fg-color">Foreground Color:</label>
            <input
              id="fg-color"
              type="color"
              value={foregroundColor}
              onChange={(e) => setForegroundColor(e.target.value)}
            />
          </div>
          <div>
            <label htmlFor="bg-color">Background Color:</label>
            <input
              id="bg-color"
              type="color"
              value={backgroundColor}
              onChange={(e) => setBackgroundColor(e.target.value)}
            />
          </div>
        </div>
        
        <button className="qr-generator-button" onClick={generateQRCode}>
          Generate QR Code
        </button>
      </div>
      
      <div className="qr-generator-display">
        <canvas ref={qrCanvasRef}></canvas>
        
        {generatedQrData && (
          <div className="qr-generator-actions">
            <button onClick={saveToMediaLibrary}>
              Save to Media Library
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default App;
