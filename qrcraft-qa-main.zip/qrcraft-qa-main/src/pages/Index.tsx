import { useState } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import QRTypeSelector, { QRType } from '@/components/QRCodeGenerator/QRTypeSelector';
import QRCodeDisplay from '@/components/QRCodeGenerator/QRCodeDisplay';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { ChromePicker } from 'react-color';
import { Check, Upload, QrCode, Download } from 'lucide-react';

const Index = () => {
  // QR Code data state
  const [qrType, setQrType] = useState<QRType>('url');
  const [qrData, setQrData] = useState('');
  const [generatedQrData, setGeneratedQrData] = useState('');
  
  // QR Code appearance options
  const [foregroundColor, setForegroundColor] = useState('#000000');
  const [backgroundColor, setBackgroundColor] = useState('#FFFFFF');
  const [showFgPicker, setShowFgPicker] = useState(false);
  const [showBgPicker, setShowBgPicker] = useState(false);
  const [qrStyle, setQrStyle] = useState('squares');
  const [logoImage, setLogoImage] = useState<string | undefined>(undefined);

  // Form fields for different QR types
  const [urlValue, setUrlValue] = useState('https://');
  const [textValue, setTextValue] = useState('');
  const [wifiValues, setWifiValues] = useState({ ssid: '', password: '', encryption: 'WPA' });
  const [contactValues, setContactValues] = useState({ 
    name: '', 
    phone: '', 
    email: '', 
    organization: '', 
    title: '' 
  });
  const [socialValues, setSocialValues] = useState({ username: '' });
  const [emailValues, setEmailValues] = useState({ 
    email: '', 
    subject: '', 
    body: '' 
  });
  const [smsValues, setSmsValues] = useState({ 
    phone: '', 
    message: '' 
  });
  const [paymentValues, setPaymentValues] = useState({ 
    type: 'paypal', 
    identifier: '', 
    amount: '', 
    currency: 'USD', 
    memo: '' 
  });

  const generateQRCode = () => {
    let qrValue = '';
    
    switch (qrType) {
      case 'url':
        qrValue = urlValue;
        break;
      case 'text':
        qrValue = textValue;
        break;
      case 'wifi':
        qrValue = `WIFI:S:${wifiValues.ssid};T:${wifiValues.encryption};P:${wifiValues.password};;`;
        break;
      case 'contact':
        qrValue = `BEGIN:VCARD\nVERSION:3.0\nFN:${contactValues.name}\nTEL:${contactValues.phone}\nEMAIL:${contactValues.email}\nORG:${contactValues.organization}\nTITLE:${contactValues.title}\nEND:VCARD`;
        break;
      case 'instagram':
        qrValue = `https://instagram.com/${socialValues.username}`;
        break;
      case 'youtube':
        qrValue = socialValues.username.includes('youtube.com') 
          ? socialValues.username 
          : `https://youtube.com/${socialValues.username}`;
        break;
      case 'whatsapp':
        qrValue = `https://wa.me/${socialValues.username}`;
        break;
      case 'email':
        qrValue = `mailto:${emailValues.email}?subject=${encodeURIComponent(emailValues.subject)}&body=${encodeURIComponent(emailValues.body)}`;
        break;
      case 'sms':
        qrValue = `sms:${smsValues.phone}${smsValues.message ? `?body=${encodeURIComponent(smsValues.message)}` : ''}`;
        break;
      case 'payment':
        if (paymentValues.type === 'paypal') {
          qrValue = `https://paypal.me/${paymentValues.identifier}/${paymentValues.amount ? paymentValues.amount : ''}`;
        } else {
          qrValue = `${paymentValues.type}:${paymentValues.identifier}${paymentValues.amount ? `?amount=${paymentValues.amount}` : ''}${paymentValues.memo ? `&memo=${encodeURIComponent(paymentValues.memo)}` : ''}`;
        }
        break;
      default:
        qrValue = '';
    }

    setGeneratedQrData(qrValue);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setLogoImage(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const renderQRTypeForm = () => {
    switch (qrType) {
      case 'url':
        return (
          <div className="space-y-4">
            <Label htmlFor="url">Website URL</Label>
            <Input 
              id="url"
              type="url" 
              placeholder="https://example.com" 
              value={urlValue}
              onChange={(e) => setUrlValue(e.target.value)}
            />
          </div>
        );
      case 'text':
        return (
          <div className="space-y-4">
            <Label htmlFor="text">Text Message</Label>
            <textarea 
              id="text"
              className="w-full min-h-[100px] p-2 border rounded-md" 
              placeholder="Enter your text here..." 
              value={textValue}
              onChange={(e) => setTextValue(e.target.value)}
            />
          </div>
        );
      case 'wifi':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="ssid">Network Name (SSID)</Label>
              <Input 
                id="ssid"
                placeholder="WiFi Network Name" 
                value={wifiValues.ssid}
                onChange={(e) => setWifiValues({...wifiValues, ssid: e.target.value})}
              />
            </div>
            <div>
              <Label htmlFor="password">Password</Label>
              <Input 
                id="password"
                type="password" 
                placeholder="WiFi Password" 
                value={wifiValues.password}
                onChange={(e) => setWifiValues({...wifiValues, password: e.target.value})}
              />
            </div>
            <div>
              <Label htmlFor="encryption">Encryption</Label>
              <select 
                id="encryption"
                className="w-full p-2 border rounded-md" 
                value={wifiValues.encryption}
                onChange={(e) => setWifiValues({...wifiValues, encryption: e.target.value})}
              >
                <option value="WPA">WPA/WPA2</option>
                <option value="WEP">WEP</option>
                <option value="nopass">No Password</option>
              </select>
            </div>
          </div>
        );
      case 'contact':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="name">Full Name</Label>
              <Input 
                id="name"
                placeholder="John Doe" 
                value={contactValues.name}
                onChange={(e) => setContactValues({...contactValues, name: e.target.value})}
              />
            </div>
            <div>
              <Label htmlFor="phone">Phone Number</Label>
              <Input 
                id="phone"
                placeholder="+1234567890" 
                value={contactValues.phone}
                onChange={(e) => setContactValues({...contactValues, phone: e.target.value})}
              />
            </div>
            <div>
              <Label htmlFor="email">Email</Label>
              <Input 
                id="email"
                type="email" 
                placeholder="johndoe@example.com" 
                value={contactValues.email}
                onChange={(e) => setContactValues({...contactValues, email: e.target.value})}
              />
            </div>
            <div>
              <Label htmlFor="organization">Organization</Label>
              <Input 
                id="organization"
                placeholder="Company Name" 
                value={contactValues.organization}
                onChange={(e) => setContactValues({...contactValues, organization: e.target.value})}
              />
            </div>
            <div>
              <Label htmlFor="title">Job Title</Label>
              <Input 
                id="title"
                placeholder="Software Engineer" 
                value={contactValues.title}
                onChange={(e) => setContactValues({...contactValues, title: e.target.value})}
              />
            </div>
          </div>
        );
      case 'instagram':
      case 'youtube':
      case 'whatsapp':
        return (
          <div className="space-y-4">
            <Label htmlFor="username">
              {qrType === 'instagram' ? 'Instagram Username' : 
               qrType === 'youtube' ? 'YouTube Channel URL or ID' : 
               'WhatsApp Number (with country code)'}
            </Label>
            <Input 
              id="username"
              placeholder={
                qrType === 'instagram' ? 'username (without @)' : 
                qrType === 'youtube' ? 'youtube.com/channel/ABC123 or @channelname' : 
                '+1234567890'
              } 
              value={socialValues.username}
              onChange={(e) => setSocialValues({username: e.target.value})}
            />
          </div>
        );
      case 'email':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="emailAddress">Email Address</Label>
              <Input 
                id="emailAddress"
                type="email" 
                placeholder="recipient@example.com" 
                value={emailValues.email}
                onChange={(e) => setEmailValues({...emailValues, email: e.target.value})}
              />
            </div>
            <div>
              <Label htmlFor="subject">Subject</Label>
              <Input 
                id="subject"
                placeholder="Email Subject" 
                value={emailValues.subject}
                onChange={(e) => setEmailValues({...emailValues, subject: e.target.value})}
              />
            </div>
            <div>
              <Label htmlFor="body">Message Body</Label>
              <textarea 
                id="body"
                className="w-full min-h-[100px] p-2 border rounded-md" 
                placeholder="Your email message..." 
                value={emailValues.body}
                onChange={(e) => setEmailValues({...emailValues, body: e.target.value})}
              />
            </div>
          </div>
        );
      case 'sms':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="phoneNumber">Phone Number</Label>
              <Input 
                id="phoneNumber"
                placeholder="+1234567890" 
                value={smsValues.phone}
                onChange={(e) => setSmsValues({...smsValues, phone: e.target.value})}
              />
            </div>
            <div>
              <Label htmlFor="message">Message (optional)</Label>
              <textarea 
                id="message"
                className="w-full min-h-[100px] p-2 border rounded-md" 
                placeholder="Your SMS message..." 
                value={smsValues.message}
                onChange={(e) => setSmsValues({...smsValues, message: e.target.value})}
              />
            </div>
          </div>
        );
      case 'payment':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="paymentType">Payment Type</Label>
              <select 
                id="paymentType"
                className="w-full p-2 border rounded-md" 
                value={paymentValues.type}
                onChange={(e) => setPaymentValues({...paymentValues, type: e.target.value})}
              >
                <option value="paypal">PayPal</option>
                <option value="bitcoin">Bitcoin</option>
                <option value="ethereum">Ethereum</option>
                <option value="upi">UPI (India)</option>
              </select>
            </div>
            <div>
              <Label htmlFor="identifier">
                {paymentValues.type === 'paypal' ? 'PayPal Username' :
                 paymentValues.type === 'bitcoin' || paymentValues.type === 'ethereum' ? 'Wallet Address' :
                 'UPI ID'}
              </Label>
              <Input 
                id="identifier"
                placeholder={
                  paymentValues.type === 'paypal' ? 'username' :
                  paymentValues.type === 'bitcoin' || paymentValues.type === 'ethereum' ? '0x...' :
                  'user@ybl'
                } 
                value={paymentValues.identifier}
                onChange={(e) => setPaymentValues({...paymentValues, identifier: e.target.value})}
              />
            </div>
            <div>
              <Label htmlFor="amount">Amount (optional)</Label>
              <Input 
                id="amount"
                type="number" 
                placeholder="10.00" 
                value={paymentValues.amount}
                onChange={(e) => setPaymentValues({...paymentValues, amount: e.target.value})}
              />
            </div>
            {paymentValues.type === 'paypal' && (
              <div>
                <Label htmlFor="currency">Currency</Label>
                <select 
                  id="currency"
                  className="w-full p-2 border rounded-md" 
                  value={paymentValues.currency}
                  onChange={(e) => setPaymentValues({...paymentValues, currency: e.target.value})}
                >
                  <option value="USD">USD ($)</option>
                  <option value="EUR">EUR (€)</option>
                  <option value="GBP">GBP (£)</option>
                  <option value="JPY">JPY (¥)</option>
                </select>
              </div>
            )}
            <div>
              <Label htmlFor="memo">Memo/Description (optional)</Label>
              <Input 
                id="memo"
                placeholder="Payment for services" 
                value={paymentValues.memo}
                onChange={(e) => setPaymentValues({...paymentValues, memo: e.target.value})}
              />
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-b from-white to-purple-50 py-16 px-4">
          <div className="container mx-auto max-w-6xl">
            <div className="text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-indigo-600">
                Create Custom QR Codes in Seconds
              </h1>
              <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-8">
                Generate QR codes for websites, text, wifi, contact info, and more. Customize colors and add your logo.
              </p>
              <a 
                href="#generator" 
                className="inline-block bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-6 py-3 rounded-lg font-medium shadow-md hover:shadow-lg transition-all"
              >
                Create QR Code Now
              </a>
            </div>
          </div>
        </section>

        {/* Generator Section */}
        <section id="generator" className="py-16 px-4">
          <div className="container mx-auto max-w-6xl">
            <h2 className="text-3xl font-bold mb-8 text-center">QR Code Generator</h2>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Left Column - Options */}
              <div className="space-y-6">
                {/* QR Type Selector */}
                <Card className="p-6">
                  <QRTypeSelector selectedType={qrType} onSelectType={setQrType} />
                </Card>
                
                {/* QR Content Form */}
                <Card className="p-6">
                  <h3 className="text-xl font-medium mb-4">QR Code Content</h3>
                  {renderQRTypeForm()}
                  <Button 
                    className="w-full mt-4 bg-primary hover:bg-primary/90" 
                    onClick={generateQRCode}
                  >
                    Generate QR Code
                  </Button>
                </Card>
                
                {/* Customization Options */}
                <Card className="p-6">
                  <h3 className="text-xl font-medium mb-4">Customize Appearance</h3>
                  <Tabs defaultValue="colors">
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="colors">Colors</TabsTrigger>
                      <TabsTrigger value="logo">Logo</TabsTrigger>
                    </TabsList>
                    <TabsContent value="colors" className="space-y-4 mt-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label>Foreground Color</Label>
                          <div className="relative">
                            <div 
                              className="w-full h-10 rounded-md border cursor-pointer flex items-center justify-between px-3"
                              style={{ backgroundColor: foregroundColor }}
                              onClick={() => setShowFgPicker(!showFgPicker)}
                            >
                              <span className="text-white text-shadow-sm">{foregroundColor}</span>
                            </div>
                            {showFgPicker && (
                              <div className="absolute z-10 mt-2">
                                <div 
                                  className="fixed inset-0" 
                                  onClick={() => setShowFgPicker(false)}
                                />
                                <ChromePicker 
                                  color={foregroundColor}
                                  onChange={(color) => setForegroundColor(color.hex)}
                                />
                              </div>
                            )}
                          </div>
                        </div>
                        <div>
                          <Label>Background Color</Label>
                          <div className="relative">
                            <div 
                              className="w-full h-10 rounded-md border cursor-pointer flex items-center justify-between px-3"
                              style={{ backgroundColor: backgroundColor }}
                              onClick={() => setShowBgPicker(!showBgPicker)}
                            >
                              <span>{backgroundColor}</span>
                            </div>
                            {showBgPicker && (
                              <div className="absolute z-10 mt-2">
                                <div 
                                  className="fixed inset-0" 
                                  onClick={() => setShowBgPicker(false)}
                                />
                                <ChromePicker 
                                  color={backgroundColor}
                                  onChange={(color) => setBackgroundColor(color.hex)}
                                />
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                      <div>
                        <Label>QR Style</Label>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mt-2">
                          <Button
                            type="button"
                            variant={qrStyle === 'squares' ? 'default' : 'outline'}
                            className="h-16 relative"
                            onClick={() => setQrStyle('squares')}
                          >
                            <div className="absolute inset-0 flex items-center justify-center">
                              <div className="grid grid-cols-3 gap-1">
                                {Array(9).fill(0).map((_, i) => (
                                  <div key={i} className="w-2 h-2 bg-current"></div>
                                ))}
                              </div>
                            </div>
                            {qrStyle === 'squares' && (
                              <Check className="absolute bottom-1 right-1 h-4 w-4" />
                            )}
                          </Button>
                          <Button
                            type="button"
                            variant={qrStyle === 'dots' ? 'default' : 'outline'}
                            className="h-16 relative"
                            onClick={() => setQrStyle('dots')}
                          >
                            <div className="absolute inset-0 flex items-center justify-center">
                              <div className="grid grid-cols-3 gap-1">
                                {Array(9).fill(0).map((_, i) => (
                                  <div key={i} className="w-2 h-2 rounded-full bg-current"></div>
                                ))}
                              </div>
                            </div>
                            {qrStyle === 'dots' && (
                              <Check className="absolute bottom-1 right-1 h-4 w-4" />
                            )}
                          </Button>
                        </div>
                      </div>
                    </TabsContent>
                    <TabsContent value="logo" className="space-y-4 mt-4">
                      <div className="flex flex-col items-center">
                        <Label htmlFor="logo-upload" className="w-full mb-2">Upload Logo (optional)</Label>
                        <div className="file-drop-area w-full p-8 border-2 border-dashed border-gray-300 rounded-lg text-center">
                          {logoImage ? (
                            <div className="flex flex-col items-center">
                              <img src={logoImage} alt="Logo" className="w-20 h-20 object-contain mb-2" />
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => setLogoImage(undefined)}
                              >
                                Remove Logo
                              </Button>
                            </div>
                          ) : (
                            <div className="flex flex-col items-center">
                              <Upload className="h-12 w-12 text-gray-400 mb-2" />
                              <p className="text-sm text-gray-500">Click to upload or drag and drop</p>
                              <p className="text-xs text-gray-400 mt-1">SVG, PNG or JPG (max. 800x800px)</p>
                              <input
                                id="logo-upload"
                                type="file"
                                accept="image/*"
                                className="hidden"
                                onChange={handleFileChange}
                              />
                              <Button
                                variant="outline"
                                className="mt-4"
                                onClick={() => document.getElementById('logo-upload')?.click()}
                              >
                                Choose File
                              </Button>
                            </div>
                          )}
                        </div>
                        <p className="text-xs text-gray-500 mt-2">
                          For best results, use a transparent PNG with a simple design
                        </p>
                      </div>
                    </TabsContent>
                  </Tabs>
                </Card>
              </div>
              
              {/* Right Column - QR Code Display */}
              <div className="lg:sticky lg:top-20 self-start">
                <QRCodeDisplay 
                  qrCodeData={generatedQrData} 
                  downloadFileName={qrType}
                  qrOptions={{
                    foreground: foregroundColor,
                    background: backgroundColor,
                    logoImage: logoImage,
                    qrStyle: qrStyle
                  }}
                />
                <div className="mt-6 text-center text-sm text-gray-500">
                  <p>Scan the QR code with your mobile device's camera</p>
                  <p className="mt-1">or download it to use anywhere</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section id="features" className="py-16 px-4 bg-gradient-to-b from-white to-purple-50">
          <div className="container mx-auto max-w-6xl">
            <h2 className="text-3xl font-bold mb-12 text-center">Key Features</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <QrCode className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Multiple QR Types</h3>
                <p className="text-gray-600">Create QR codes for websites, text, WiFi, contacts, social media, and more.</p>
              </div>
              <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" className="h-6 w-6 text-primary"><circle cx="13.5" cy="6.5" r="2.5"></circle><circle cx="19" cy="17" r="2"></circle><circle cx="5" cy="17" r="2"></circle><path d="M8 17h8"></path><path d="m13.5 9-3.5 8"></path><path d="m13.5 9 5.5 8"></path></svg>
                </div>
                <h3 className="text-xl font-semibold mb-2">Customization</h3>
                <p className="text-gray-600">Personalize your QR code with custom colors and add your logo.</p>
              </div>
              <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <Download className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Download & Share</h3>
                <p className="text-gray-600">Download your QR code in PNG format or share it directly with others.</p>
              </div>
            </div>
          </div>
        </section>

        {/* How It Works Section */}
        <section id="how-it-works" className="py-16 px-4">
          <div className="container mx-auto max-w-6xl">
            <h2 className="text-3xl font-bold mb-12 text-center">How It Works</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="relative mx-auto h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <span className="text-xl font-bold text-primary">1</span>
                </div>
                <h3 className="text-xl font-semibold mb-2">Select QR Type</h3>
                <p className="text-gray-600">Choose from various QR code types like URL, text, WiFi, etc.</p>
              </div>
              <div className="text-center">
                <div className="relative mx-auto h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <span className="text-xl font-bold text-primary">2</span>
                </div>
                <h3 className="text-xl font-semibold mb-2">Enter Content</h3>
                <p className="text-gray-600">Fill in the required information based on your selected QR type.</p>
              </div>
              <div className="text-center">
                <div className="relative mx-auto h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <span className="text-xl font-bold text-primary">3</span>
                </div>
                <h3 className="text-xl font-semibold mb-2">Download</h3>
                <p className="text-gray-600">Customize your QR code appearance and download or share it.</p>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default Index;
