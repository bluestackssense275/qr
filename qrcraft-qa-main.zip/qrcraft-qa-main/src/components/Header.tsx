
import { useState, useEffect } from 'react';
import { QrCode } from 'lucide-react';

const Header = () => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <header className={`sticky top-0 z-50 w-full transition-all duration-200 ${
      scrolled ? 'bg-white/90 backdrop-blur-md shadow-sm' : 'bg-transparent'
    }`}>
      <div className="container flex items-center justify-between h-16 px-4 md:px-6">
        <div className="flex items-center gap-2">
          <QrCode className="h-6 w-6 text-qr-primary" />
          <span className="font-bold text-lg text-qr-primary">QRCraft</span>
        </div>
        <nav className="hidden md:flex items-center gap-6">
          <a href="#features" className="text-sm font-medium hover:text-qr-primary transition-colors">
            Features
          </a>
          <a href="#how-it-works" className="text-sm font-medium hover:text-qr-primary transition-colors">
            How It Works
          </a>
          <a href="#generator" className="text-sm font-medium hover:text-qr-primary transition-colors">
            Create QR Code
          </a>
        </nav>
      </div>
    </header>
  );
};

export default Header;
