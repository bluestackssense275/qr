
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { QrCode, Globe, MessageSquare, Wifi, Contact, Instagram, Youtube, Mail, Smartphone, DollarSign } from 'lucide-react';
import { cn } from '@/lib/utils';

export type QRType = 
  | 'url' 
  | 'text' 
  | 'wifi' 
  | 'contact' 
  | 'instagram' 
  | 'youtube' 
  | 'whatsapp' 
  | 'email' 
  | 'sms'
  | 'payment';

interface QRTypeSelectorProps {
  selectedType: QRType;
  onSelectType: (type: QRType) => void;
}

interface TypeOption {
  id: QRType;
  name: string;
  icon: React.ReactNode;
  description: string;
}

const QRTypeSelector = ({ selectedType, onSelectType }: QRTypeSelectorProps) => {
  const typeOptions: TypeOption[] = [
    { id: 'url', name: 'Website URL', icon: <Globe className="w-5 h-5" />, description: 'Link to a website' },
    { id: 'text', name: 'Text', icon: <MessageSquare className="w-5 h-5" />, description: 'Plain text message' },
    { id: 'wifi', name: 'WiFi', icon: <Wifi className="w-5 h-5" />, description: 'WiFi network details' },
    { id: 'contact', name: 'Contact', icon: <Contact className="w-5 h-5" />, description: 'Contact information' },
    { id: 'instagram', name: 'Instagram', icon: <Instagram className="w-5 h-5" />, description: 'Instagram profile link' },
    { id: 'youtube', name: 'YouTube', icon: <Youtube className="w-5 h-5" />, description: 'YouTube video or channel' },
    { id: 'whatsapp', name: 'WhatsApp', icon: <Smartphone className="w-5 h-5" />, description: 'WhatsApp contact or message' },
    { id: 'email', name: 'Email', icon: <Mail className="w-5 h-5" />, description: 'Email address or message' },
    { id: 'sms', name: 'SMS', icon: <Smartphone className="w-5 h-5" />, description: 'SMS text message' },
    { id: 'payment', name: 'Payment', icon: <DollarSign className="w-5 h-5" />, description: 'Payment links (PayPal, etc)' },
  ];

  return (
    <div className="w-full">
      <div className="mb-2">
        <h2 className="text-lg font-medium">QR Code Type</h2>
        <p className="text-sm text-gray-500">Select the type of QR code you want to create</p>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
        {typeOptions.map((type) => (
          <Button
            key={type.id}
            variant="outline"
            className={cn(
              "h-auto flex flex-col items-center gap-1 py-2 px-3 justify-start text-start",
              selectedType === type.id && "border-primary bg-primary/5"
            )}
            onClick={() => onSelectType(type.id)}
          >
            <div className="flex flex-col items-center gap-1">
              {type.icon}
              <span className="text-xs font-medium">{type.name}</span>
            </div>
          </Button>
        ))}
      </div>
    </div>
  );
};

export default QRTypeSelector;
