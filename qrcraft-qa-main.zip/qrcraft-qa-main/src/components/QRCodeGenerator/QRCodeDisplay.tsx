
import { useEffect, useRef } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Download, Share2 } from 'lucide-react';
import { toast } from 'sonner';

interface QRCodeDisplayProps {
  qrCodeData: string;
  downloadFileName?: string;
  qrOptions: {
    foreground: string;
    background: string;
    logoImage?: string;
    qrStyle: string;
  };
}

const QRCodeDisplay = ({ 
  qrCodeData, 
  downloadFileName = 'qrcode', 
  qrOptions 
}: QRCodeDisplayProps) => {
  const qrCodeRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const loadQRCode = async () => {
      if (qrCodeRef.current && qrCodeData) {
        try {
          // Import QRCode.js dynamically
          const QRCode = await import('qrcode');
          const canvas = document.createElement('canvas');
          
          // Clear previous QR code
          while (qrCodeRef.current.firstChild) {
            qrCodeRef.current.removeChild(qrCodeRef.current.firstChild);
          }
          
          // Generate QR code
          await QRCode.toCanvas(canvas, qrCodeData, {
            margin: 1,
            width: 250,
            color: {
              dark: qrOptions.foreground,
              light: qrOptions.background
            }
          });
          
          // Add canvas to the div
          qrCodeRef.current.appendChild(canvas);
          
          // If logo is present, add it to the center of the QR code
          if (qrOptions.logoImage) {
            const img = new Image();
            img.src = qrOptions.logoImage;
            img.onload = () => {
              const ctx = canvas.getContext('2d');
              if (ctx) {
                // Calculate logo size (25% of QR code)
                const logoSize = canvas.width * 0.25;
                const logoX = (canvas.width - logoSize) / 2;
                const logoY = (canvas.height - logoSize) / 2;
                
                // Create white background for logo
                ctx.fillStyle = qrOptions.background;
                ctx.fillRect(logoX - 5, logoY - 5, logoSize + 10, logoSize + 10);
                
                // Draw logo
                ctx.drawImage(img, logoX, logoY, logoSize, logoSize);
              }
            };
          }
        } catch (error) {
          console.error('Failed to generate QR code:', error);
        }
      }
    };
    
    loadQRCode();
  }, [qrCodeData, qrOptions]);

  const handleDownload = async (format: 'png' | 'svg' | 'pdf') => {
    if (!qrCodeRef.current || !qrCodeRef.current.firstChild) {
      toast.error('QR code is not generated yet');
      return;
    }

    try {
      let url;
      const canvas = qrCodeRef.current.querySelector('canvas');
      
      if (!canvas) {
        toast.error('QR code canvas not found');
        return;
      }

      if (format === 'png') {
        url = canvas.toDataURL('image/png');
      } else {
        // For now we'll use PNG for all formats until we add SVG/PDF conversion
        url = canvas.toDataURL('image/png');
        toast('SVG/PDF formats coming soon! Downloading as PNG instead.', {
          description: 'We\'re working on adding SVG and PDF export options.',
        });
      }

      // Create temporary link and trigger download
      const link = document.createElement('a');
      link.download = `${downloadFileName}.${format}`;
      link.href = url;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      toast.success('QR code downloaded successfully!');
    } catch (error) {
      console.error('Download failed:', error);
      toast.error('Failed to download QR code');
    }
  };

  const handleShare = async () => {
    if (!qrCodeRef.current || !qrCodeRef.current.firstChild) {
      toast.error('QR code is not generated yet');
      return;
    }

    try {
      const canvas = qrCodeRef.current.querySelector('canvas');
      
      if (!canvas) {
        toast.error('QR code canvas not found');
        return;
      }

      // Convert canvas to blob
      const blob = await new Promise<Blob>((resolve) => {
        canvas.toBlob((blob) => {
          if (blob) resolve(blob);
          else throw new Error('Could not create blob');
        }, 'image/png');
      });

      // Check if Web Share API is supported
      if (navigator.share) {
        await navigator.share({
          title: 'QR Code from QRCraft',
          text: 'Check out this QR code I created with QRCraft!',
          files: [new File([blob], 'qrcode.png', { type: 'image/png' })],
        });
        toast.success('QR code shared successfully!');
      } else {
        // Fallback for browsers that don't support Web Share API
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.download = 'qrcode.png';
        link.href = url;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
        toast('Share not supported on this browser. QR code downloaded instead.', {
          description: 'Try a modern mobile browser for sharing features.',
        });
      }
    } catch (error) {
      console.error('Share failed:', error);
      toast.error('Failed to share QR code');
    }
  };

  return (
    <div className="flex flex-col items-center">
      <Card className="w-full max-w-md p-6 flex flex-col items-center qr-container-shadow">
        <div 
          ref={qrCodeRef} 
          className="rounded-lg overflow-hidden w-64 h-64 flex items-center justify-center bg-white"
        >
          {!qrCodeData && (
            <div className="text-center text-gray-400">
              <p>Your QR Code will appear here</p>
              <p className="text-sm">Fill in the form to generate</p>
            </div>
          )}
        </div>
        
        <div className="flex mt-4 gap-4">
          <div className="flex-1">
            <Button 
              onClick={() => handleDownload('png')}
              variant="outline" 
              className="w-full"
            >
              <Download className="mr-2 h-4 w-4" />
              Download
            </Button>
          </div>
          <div className="flex-1">
            <Button 
              onClick={handleShare}
              variant="outline" 
              className="w-full"
            >
              <Share2 className="mr-2 h-4 w-4" />
              Share
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default QRCodeDisplay;
