
import { QrCode, Github, Twitter } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gradient-to-b from-white to-purple-50 py-12 mt-20">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center gap-2 mb-6 md:mb-0">
            <QrCode className="h-6 w-6 text-qr-primary" />
            <span className="font-bold text-lg text-qr-primary">QRCraft</span>
          </div>
          <div className="flex flex-col md:flex-row gap-6 md:gap-12 text-center md:text-left">
            <a href="#features" className="text-sm font-medium text-gray-600 hover:text-qr-primary transition-colors">
              Features
            </a>
            <a href="#how-it-works" className="text-sm font-medium text-gray-600 hover:text-qr-primary transition-colors">
              How It Works
            </a>
            <a href="#generator" className="text-sm font-medium text-gray-600 hover:text-qr-primary transition-colors">
              Create QR Code
            </a>
          </div>
        </div>
        <div className="border-t border-gray-200 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-gray-500">
            © {new Date().getFullYear()} QRCraft. All rights reserved.
          </p>
          <div className="flex items-center gap-4 mt-4 md:mt-0">
            <a href="#" className="text-gray-500 hover:text-qr-primary transition-colors">
              <Github className="h-5 w-5" />
              <span className="sr-only">GitHub</span>
            </a>
            <a href="#" className="text-gray-500 hover:text-qr-primary transition-colors">
              <Twitter className="h-5 w-5" />
              <span className="sr-only">Twitter</span>
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
